
// Get the button and revealed text elements
const button = document.getElementById('revealButton');
const revealedText = document.getElementById('revealedText');

// Add click event listener to the button
button.addEventListener('click', function() {
  // Expand the button and show the revealed text
  button.classList.add('expanded');
  revealedText.style.display = 'block';
});
